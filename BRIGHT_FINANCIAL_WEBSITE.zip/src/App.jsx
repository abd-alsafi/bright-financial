export default function App(){
return (
<div style={{background:'#071018',minHeight:'100vh',color:'white',padding:'40px',fontFamily:'Arial'}}>
<h1>BRIGHT FINANCIAL CO.</h1>
<p>Arabic / English Financial Services Website</p>
<ul>
<li>Portfolio Management</li>
<li>Financial Consulting</li>
<li>Forex Trading</li>
<li>Risk Management</li>
<li>Technical & Fundamental Analysis</li>
</ul>
<p>WhatsApp: +964 774 277 7047</p>
<p>Instagram: @bright.financial</p>
</div>
)}
